﻿using System.Data;
using System.Data.SqlClient;

namespace LetterNotesProject.DAL
{
    public class AppDbContex
    {
        private readonly string _connectionString;

        public AppDbContex(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("DefaultConnection");
        }


        // ---------------------------------------
        // SELECT without parameters
        // ---------------------------------------
        public DataTable Select(string query)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }


        // ---------------------------------------
        // SELECT with parameters
        // ---------------------------------------
        public DataTable Select(string query, SqlParameter[] parameters)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, con);

                if (parameters != null)  // ✔ مهم جداً
                    cmd.Parameters.AddRange(parameters);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                return dt;
            }
        }


        // ---------------------------------------
        // EXECUTE (INSERT, UPDATE, DELETE)
        // ---------------------------------------
        public int Execute(string query, SqlParameter[] parameters)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(query, con);

                if (parameters != null)  // ✔ يمنع AddRange(null)
                    cmd.Parameters.AddRange(parameters);

                return cmd.ExecuteNonQuery();
            }
        }
    }
}
