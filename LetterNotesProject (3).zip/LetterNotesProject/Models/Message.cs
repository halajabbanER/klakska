﻿namespace LetterNotesProject.Models
{
    public class Message
    {

        public int MessageID { get; set; }
            public int SenderID { get; set; }
            public int ReceiverID { get; set; }
            public string Subject { get; set; }
            public string Body { get; set; }
            public DateTime SentDate { get; set; }
        
             public string SenderName { get; set; }
            public string ReceiverName { get; set; }
        //for status
        public int StatusID { get; set; }
        public string StatusName { get; set; }

    }

}


