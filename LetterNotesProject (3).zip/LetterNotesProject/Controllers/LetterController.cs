﻿using LetterNotesProject.DAL;
using LetterNotesProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace LetterNotesProject.Controllers
{
    public class LetterController : Controller
    {
        private readonly AppDbContex _db;

        public LetterController(IConfiguration config)
        {
            _db = new AppDbContex(config);
        }

        // ========================= INDEX =========================
        public IActionResult Index()
        {
            string q = @"
                SELECT 
                    m.MessageID, m.Subject, m.Body, m.SentDate, m.StatusID,
                    u1.FullName AS SenderName,
                    u2.FullName AS ReceiverName,
                    s.StatusName
                FROM Messages m
                JOIN Users u1 ON m.SenderID = u1.UserID
                JOIN Users u2 ON m.ReceiverID = u2.UserID
                JOIN LetterStatus s ON m.StatusID = s.StatusID
            ";

            DataTable dt = _db.Select(q);

            List<Message> messages = new List<Message>();

            foreach (DataRow row in dt.Rows)
            {
                messages.Add(new Message
                {
                    MessageID = Convert.ToInt32(row["MessageID"]),
                    Subject = row["Subject"].ToString(),
                    Body = row["Body"].ToString(),
                    SentDate = Convert.ToDateTime(row["SentDate"]),
                    SenderName = row["SenderName"].ToString(),
                    ReceiverName = row["ReceiverName"].ToString(),
                    StatusID = Convert.ToInt32(row["StatusID"]),
                    StatusName = row["StatusName"].ToString()
                });
            }

            return View(messages);
        }



        // ========================= CREATE GET =========================
        public IActionResult Create()
        {
            ViewBag.Users = _db.Select("SELECT UserID, FullName FROM Users");
            return View();
        }

        // ========================= CREATE POST =========================
        [HttpPost]
        public IActionResult Create(Message msg)
        {
            string q = @"
                INSERT INTO Messages (SenderID, ReceiverID, Subject, Body, StatusID)
                VALUES (@SenderID, @ReceiverID, @Subject, @Body, 1)
            ";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@SenderID", msg.SenderID),
                new SqlParameter("@ReceiverID", msg.ReceiverID),
                new SqlParameter("@Subject", msg.Subject),
                new SqlParameter("@Body", msg.Body),
                
                
            };

            _db.Execute(q, prms);

            return RedirectToAction("Index");
        }



        // ========================= DETAILS =========================
        public IActionResult Details(int id)
        {
            // Change to READ
            _db.Execute($"UPDATE Messages SET StatusID = 3 WHERE MessageID = {id}", null);

            string q = @"
                SELECT 
                    m.*, 
                    u1.FullName AS SenderName, 
                    u2.FullName AS ReceiverName,
                    s.StatusName
                FROM Messages m
                JOIN Users u1 ON m.SenderID = u1.UserID
                JOIN Users u2 ON m.ReceiverID = u2.UserID
                JOIN LetterStatus s ON m.StatusID = s.StatusID
                WHERE m.MessageID = @id
            ";

            SqlParameter[] prms = { new SqlParameter("@id", id) };

            DataTable dt = _db.Select(q, prms);

            if (dt.Rows.Count == 0) return NotFound();

            DataRow row = dt.Rows[0];

            Message msg = new Message
            {
                MessageID = id,
                Subject = row["Subject"].ToString(),
                Body = row["Body"].ToString(),
                SenderName = row["SenderName"].ToString(),
                ReceiverName = row["ReceiverName"].ToString(),
                SentDate = Convert.ToDateTime(row["SentDate"]),
                StatusID = Convert.ToInt32(row["StatusID"]),
                StatusName = row["StatusName"].ToString()
            };

            return View(msg);
        }



        // ========================= EDIT GET =========================
        public IActionResult Edit(int id)
        {
            string q = @"
        SELECT 
            m.MessageID, m.SenderID, m.ReceiverID,
            m.Subject, m.Body, m.StatusID,
            u1.FullName AS SenderName,
            u2.FullName AS ReceiverName,
            s.StatusName
        FROM Messages m
        JOIN Users u1 ON m.SenderID = u1.UserID
        JOIN Users u2 ON m.ReceiverID = u2.UserID
        JOIN LetterStatus s ON m.StatusID = s.StatusID
        WHERE m.MessageID = @id
    ";

            SqlParameter[] prms = { new SqlParameter("@id", id) };

            DataTable dt = _db.Select(q, prms);

            if (dt.Rows.Count == 0) return NotFound();

            DataRow row = dt.Rows[0];

            Message msg = new Message
            {
                MessageID = id,
                SenderID = Convert.ToInt32(row["SenderID"]),
                ReceiverID = Convert.ToInt32(row["ReceiverID"]),
                Subject = row["Subject"].ToString(),
                Body = row["Body"].ToString(),
                StatusID = Convert.ToInt32(row["StatusID"]),
                StatusName = row["StatusName"].ToString()
            };

            // لعرض قائمة المستخدمين
            ViewBag.Users = _db.Select("SELECT UserID, FullName FROM Users");

            return View(msg);
        }
        // ========================= EDIT POST =========================
        [HttpPost]
        public IActionResult Edit(Message msg)
        {
            string q = @"
        UPDATE Messages SET 
            SenderID = @SenderID,
            ReceiverID = @ReceiverID,
            Subject = @Subject,
            Body = @Body,
            StatusID = 1   -- ترجع Sent
        WHERE MessageID = @MessageID
    ";

            SqlParameter[] prms = new SqlParameter[]
            {
        new SqlParameter("@SenderID", msg.SenderID),
        new SqlParameter("@ReceiverID", msg.ReceiverID),
        new SqlParameter("@Subject", msg.Subject),
        new SqlParameter("@Body", msg.Body),
        new SqlParameter("@MessageID", msg.MessageID)
            };

            _db.Execute(q, prms);

            return RedirectToAction("Index");
        }

        // ========================= DELETE GET =========================
        public IActionResult Delete(int id)
        {
            string q = @"
        SELECT 
            m.*, 
            u1.FullName AS SenderName,
            u2.FullName AS ReceiverName,
            s.StatusName
        FROM Messages m
        JOIN Users u1 ON m.SenderID = u1.UserID
        JOIN Users u2 ON m.ReceiverID = u2.UserID
        JOIN LetterStatus s ON m.StatusID = s.StatusID
        WHERE m.MessageID = @id
    ";

            SqlParameter[] prms = { new SqlParameter("@id", id) };

            DataTable dt = _db.Select(q, prms);

            if (dt.Rows.Count == 0) return NotFound();

            DataRow row = dt.Rows[0];

            Message msg = new Message
            {
                MessageID = id,
                Subject = row["Subject"].ToString(),
                Body = row["Body"].ToString(),
                SenderName = row["SenderName"].ToString(),
                ReceiverName = row["ReceiverName"].ToString(),
                StatusID = Convert.ToInt32(row["StatusID"]),
                StatusName = row["StatusName"].ToString()
            };

            return View(msg);
        }
        // ========================= DELETE POST =========================
        [HttpPost]
        public IActionResult DeleteConfirmed(int MessageID)
        {
            string q = "DELETE FROM Messages WHERE MessageID = @MessageID";

            SqlParameter[] prms = {
        new SqlParameter("@MessageID", MessageID)
    };

            _db.Execute(q, prms);

            return RedirectToAction("Index");
        }

        // ========================= INBOX =========================
        public IActionResult Inbox(int id)
        {
            // Mark messages as DELIVERED (2)
            _db.Execute($"UPDATE Messages SET StatusID = 2 WHERE ReceiverID = {id} AND StatusID = 1", null);

            string q = @"
                SELECT 
                    m.MessageID, m.Subject, m.Body, m.SentDate, m.StatusID,
                    u.FullName AS SenderName,
                    s.StatusName
                FROM Messages m
                JOIN Users u ON m.SenderID = u.UserID
                JOIN LetterStatus s ON m.StatusID = s.StatusID
                WHERE m.ReceiverID = @UserID
            ";

            SqlParameter[] prms = { new SqlParameter("@UserID", id) };

            DataTable dt = _db.Select(q, prms);

            List<Message> messages = new List<Message>();

            foreach (DataRow row in dt.Rows)
            {
                messages.Add(new Message
                {
                    MessageID = Convert.ToInt32(row["MessageID"]),
                    Subject = row["Subject"].ToString(),
                    Body = row["Body"].ToString(),
                    SentDate = Convert.ToDateTime(row["SentDate"]),
                    SenderName = row["SenderName"].ToString(),
                    StatusID = Convert.ToInt32(row["StatusID"]),
                    StatusName = row["StatusName"].ToString()
                });
            }

            return View(messages);
        }



        // ========================= SENT =========================
        public IActionResult Sent(int id)
        {
            string q = @"
                SELECT 
                    m.MessageID, m.Subject, m.Body, m.SentDate, m.StatusID,
                    u.FullName AS ReceiverName,
                    s.StatusName
                FROM Messages m
                JOIN Users u ON m.ReceiverID = u.UserID
                JOIN LetterStatus s ON m.StatusID = s.StatusID
                WHERE m.SenderID = @UserID
            ";

            SqlParameter[] prms = { new SqlParameter("@UserID", id) };

            DataTable dt = _db.Select(q, prms);

            List<Message> messages = new List<Message>();

            foreach (DataRow row in dt.Rows)
            {
                messages.Add(new Message
                {
                    MessageID = Convert.ToInt32(row["MessageID"]),
                    Subject = row["Subject"].ToString(),
                    Body = row["Body"].ToString(),
                    SentDate = Convert.ToDateTime(row["SentDate"]),
                    ReceiverName = row["ReceiverName"].ToString(),
                    StatusID = Convert.ToInt32(row["StatusID"]),
                    StatusName = row["StatusName"].ToString()
                });
            }

            return View(messages);
        }
    }
}
