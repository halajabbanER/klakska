﻿using LetterNotesProject.DAL;
using LetterNotesProject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace LetterNotesProject.Controllers
{
    public class UserController : Controller
    {
        private readonly AppDbContex _db;

        public UserController(IConfiguration config)
        {
            _db = new AppDbContex(config);
        }

        // ---------------------- INDEX ----------------------
        public IActionResult Index()
        {
            DataTable dt = _db.Select("SELECT * FROM Users");
            List<User> users = new List<User>();

            foreach (DataRow row in dt.Rows)
            {
                users.Add(new User
                {
                    UserID = Convert.ToInt32(row["UserID"]),
                    UserName = row["UserName"].ToString(),
                    FullName = row["FullName"].ToString(),
                    Email = row["Email"].ToString(),
                    password = row["Password"].ToString(),
                    Phone = row["Phone"].ToString(),
                    roleID = row["roleID"] == DBNull.Value ? 0 : Convert.ToInt32(row["roleID"])
                });
            }

            return View(users);
        }

        // ---------------------- CREATE GET ----------------------
        public IActionResult Create()
        {
            return View();
        }

        // ---------------------- CREATE POST ----------------------
        [HttpPost]
        public IActionResult Create(User u)
        {
            string query = @"INSERT INTO Users 
                            (UserName, FullName, Email, Password, Phone, roleID) 
                            VALUES 
                            (@UserName, @FullName, @Email, @Password, @Phone, @roleID)";

            var parameters = new SqlParameter[]
            {
                new SqlParameter("@UserName", u.UserName),
                new SqlParameter("@FullName", u.FullName),
                new SqlParameter("@Email", u.Email),
                new SqlParameter("@Password", u.password),
                new SqlParameter("@Phone", u.Phone),
                new SqlParameter("@roleID", u.roleID)
            };

            _db.Execute(query, parameters);

            return RedirectToAction("Index");
        }

        // ---------------------- EDIT GET ----------------------
        public IActionResult Edit(int id)
        {
            string query = "SELECT * FROM Users WHERE UserID = @id";

            var param = new SqlParameter[]
            {
                new SqlParameter("@id", id)
            };

            DataTable dt = _db.Select(query, param);

            if (dt.Rows.Count == 0)
                return RedirectToAction("Index");

            User u = new User
            {
                UserID = id,
                UserName = dt.Rows[0]["UserName"].ToString(),
                FullName = dt.Rows[0]["FullName"].ToString(),
                Email = dt.Rows[0]["Email"].ToString(),
                password = dt.Rows[0]["Password"].ToString(),
                Phone = dt.Rows[0]["Phone"].ToString(),
                roleID = dt.Rows[0]["roleID"] == DBNull.Value ? 0 : Convert.ToInt32(dt.Rows[0]["roleID"])
            };

            return View(u);
        }

        // ---------------------- EDIT POST ----------------------
        [HttpPost]
        public IActionResult Edit(User u)
        {
            string query = @"UPDATE Users SET
                                UserName=@UserName,
                                FullName=@FullName,
                                Email=@Email,
                                Password=@Password,
                                Phone=@Phone,
                                roleID=@roleID
                             WHERE UserID=@UserID";

            var parameters = new SqlParameter[]
            {
                new SqlParameter("@UserName", u.UserName),
                new SqlParameter("@FullName", u.FullName),
                new SqlParameter("@Email", u.Email),
                new SqlParameter("@Password", u.password),
                new SqlParameter("@Phone", u.Phone),
                new SqlParameter("@roleID", u.roleID),
                new SqlParameter("@UserID", u.UserID)
            };

            _db.Execute(query, parameters);

            return RedirectToAction("Index");
        }

        // ---------------------- DELETE GET ----------------------
        public IActionResult Delete(int id)
        {
            User u = new User();
            u.UserID = id;
            return View(u);
        }

        // ---------------------- DELETE POST ----------------------
        [HttpPost]
        public IActionResult Delete(User u)
        {
            string query = "DELETE FROM Users WHERE UserID = @UserID";

            var parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", u.UserID)
            };

            _db.Execute(query, parameters);

            return RedirectToAction("Index");
        }

        // ---------------------- DETAILS ----------------------
        public IActionResult Details(int id)
        {
            string query = "SELECT * FROM Users WHERE UserID = @id";

            var param = new SqlParameter[]
            {
                new SqlParameter("@id", id)
            };

            DataTable dt = _db.Select(query, param);

            if (dt.Rows.Count == 0)
                return RedirectToAction("Index");

            User u = new User
            {
                UserID = id,
                UserName = dt.Rows[0]["UserName"].ToString(),
                FullName = dt.Rows[0]["FullName"].ToString(),
                Email = dt.Rows[0]["Email"].ToString(),
                password = dt.Rows[0]["Password"].ToString(),
                Phone = dt.Rows[0]["Phone"].ToString(),
                roleID = dt.Rows[0]["roleID"] == DBNull.Value ? 0 : Convert.ToInt32(dt.Rows[0]["roleID"])
            };

            return View(u);
        }
    }
}
